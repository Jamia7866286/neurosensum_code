<?php

define( 'REDIRECTION_VERSION', '4.6.2' );
define( 'REDIRECTION_BUILD', 'eb8558cc89fc1abcaa7784d0cea5bb6f' );
define( 'REDIRECTION_MIN_WP', '4.6' );
